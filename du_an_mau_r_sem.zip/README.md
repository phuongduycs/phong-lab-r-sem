# Dự án mẫu: từ dữ liệu khảo sát đến bản thảo, slide và thư trả lời phản biện

Đi kèm Bài 21–23 của **Phòng Lab R–SEM** (https://phuongduycs.github.io/phong-lab-r-sem/).
Người phát triển: Nguyễn Bình Phương Duy · Giấy phép CC BY-NC 4.0.

> Dữ liệu là **mô phỏng** để học. Bản thảo chỉ minh hoạ cách trình bày, không phải nghiên cứu thật.
> Các chỗ trong ngoặc vuông `[...]` là phần bạn phải tự viết từ tài liệu thật.

## Cấu trúc

```
du_an_livestream.Rproj      mở tệp này trong RStudio (đặt thư mục làm việc đúng chỗ)
data/khao_sat_sach.csv      dữ liệu đã làm sạch (Bài 5)
R/00_cai_goi.R              cài gói, hướng dẫn renv
R/00_ham_bao_cao.R          hàm định dạng số và bảng theo APA 7
R/01_phan_tich.R            CFA, SEM (lavaan), PLS-SEM (seminr) → ket_qua/ket_qua.rds
R/02_xuat_ban.R             render bản thảo, thư phản biện, slide
ket_qua/                    kết quả đã lưu (.rds, .csv)
ban_thao/manuscript.qmd     bản thảo tiếng Anh: số liệu, bảng, hình tự cập nhật
ban_thao/references.bib     tài liệu tham khảo (thay bằng tệp xuất từ Zotero)
ban_thao/apa.csl            kiểu trích dẫn APA 7 (Citation Style Language, CC BY-SA 3.0)
ban_thao/mau_word.docx      khuôn Word: Times New Roman 12, giãn dòng đôi
ban_thao/tra_loi_phan_bien.qmd   mẫu thư trả lời phản biện từng ý
slide/bao_ve.qmd            slide bảo vệ (Quarto revealjs) + vi.css giữ dấu tiếng Việt
```

## Chạy

1. Cài R, RStudio (bản 2022.07 trở lên đã có Quarto). Mở `du_an_livestream.Rproj`.
2. Console: `source("R/00_cai_goi.R")` (một lần).
3. `source("R/01_phan_tich.R")`: khoảng 1 phút vì bootstrap 5.000 mẫu.
4. `source("R/02_xuat_ban.R")`, hoặc mở `ban_thao/manuscript.qmd` và bấm **Render**.

Kết quả: `ban_thao/manuscript.docx` (nộp tạp chí), `manuscript.html`, `tra_loi_phan_bien.docx`, `slide/bao_ve.html`.

## Dùng cho đề tài của bạn

- Thay `data/khao_sat_sach.csv` và danh sách `khai_niem` trong `R/01_phan_tich.R`.
- Sửa bảng `gia_thuyet` và dòng mô hình cấu trúc cho khớp mô hình của bạn.
- Sửa tên khái niệm tiếng Anh trong `R/00_ham_bao_cao.R` (`ten_kn`, `viet_tat`).
- Đổi khuôn Word: mở `mau_word.docx`, sửa Style (Normal, Heading 1…), lưu lại. Không gõ nội dung vào tệp này.
