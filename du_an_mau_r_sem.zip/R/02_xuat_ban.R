# =============================================================================
# 02_xuat_ban.R: render bản thảo, thư trả lời phản biện và slide bằng Quarto
# Cần: Quarto CLI (có sẵn trong RStudio 2022.07 trở lên) và gói quarto, flextable.
# =============================================================================
if (!file.exists("ket_qua/ket_qua.rds")) source("R/01_phan_tich.R")
quarto::quarto_render("ban_thao/manuscript.qmd")                 # → manuscript.docx + manuscript.html
quarto::quarto_render("ban_thao/tra_loi_phan_bien.qmd")          # → tra_loi_phan_bien.docx
quarto::quarto_render("slide/bao_ve.qmd")                        # → bao_ve.html (mở bằng trình duyệt, F để toàn màn hình)
