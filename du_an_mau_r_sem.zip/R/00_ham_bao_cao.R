# =============================================================================
# 00_ham_bao_cao.R: hàm định dạng số và bảng theo APA 7, dùng trong bản thảo và slide
# =============================================================================

# Số theo APA: k chữ số thập phân; bo0 = TRUE bỏ số 0 đứng đầu cho đại lượng không vượt quá 1
# (hệ số chuẩn hoá, tương quan, p, CFI...). Ví dụ: apa_so(0.4551, bo0 = TRUE) -> ".46"
apa_so <- function(x, k = 2, bo0 = FALSE) {
  s <- formatC(x, digits = k, format = "f")
  if (bo0) s <- sub("^(-?)0\\.", "\\1.", s)
  s
}

# Giá trị p theo APA: "< .001" hoặc "= .021" (ba chữ số, không có số 0 đứng đầu)
apa_p <- function(p) ifelse(p < .001, "< .001", paste("=", apa_so(p, 3, bo0 = TRUE)))

# Câu báo cáo một giả thuyết, lấy thẳng từ một dòng của bảng cau_truc
cau_gt <- function(d) {
  sprintf("%s (%s → %s) was %s (β = %s, *SE* = %s, *p* %s, 95%% CI [%s, %s])",
          d$H, viet_tat[[d$tu]], viet_tat[[d$den]], tolower(d$ket_luan), apa_so(d$est.std, 2, TRUE), apa_so(d$se, 2, TRUE),
          apa_p(d$pvalue), apa_so(d$ci.lower, 2, TRUE), apa_so(d$ci.upper, 2, TRUE))
}

# Câu báo cáo độ phù hợp mô hình
cau_fit <- function(f) {
  sprintf("χ²(%d) = %s, *p* %s; CFI = %s; TLI = %s; RMSEA = %s, 90%% CI [%s, %s]; SRMR = %s",
          round(f[["df.scaled"]]), apa_so(f[["chisq.scaled"]], 2), apa_p(f[["pvalue.scaled"]]),
          apa_so(f[["cfi.robust"]], 3, TRUE), apa_so(f[["tli.robust"]], 3, TRUE),
          apa_so(f[["rmsea.robust"]], 3, TRUE), apa_so(f[["rmsea.ci.lower.robust"]], 3, TRUE),
          apa_so(f[["rmsea.ci.upper.robust"]], 3, TRUE), apa_so(f[["srmr"]], 3, TRUE))
}

# Bảng APA cho Word: chữ Times New Roman 10, ba đường kẻ ngang, không kẻ dọc
bang_apa <- function(d, chu_thich = NULL) {
  ft <- flextable::flextable(d)
  ft <- flextable::theme_apa(ft)
  if (!is.null(chu_thich)) ft <- flextable::add_footer_lines(ft, chu_thich)
  ft <- flextable::font(ft, fontname = "Times New Roman", part = "all")
  ft <- flextable::fontsize(ft, size = 10, part = "all")
  ft <- flextable::align(ft, j = -1, align = "center", part = "header")
  ft <- flextable::align(ft, j = -1, align = "center", part = "body")
  flextable::autofit(ft)
}

ten_kn <- c(HI = "Perceived usefulness (PU)", DD = "Perceived ease of use (PEOU)",
            NT = "Trust in sellers (TR)", TD = "Attitude (ATT)", YD = "Purchase intention (PI)")
viet_tat <- c(HI = "PU", DD = "PEOU", NT = "TR", TD = "ATT", YD = "PI")
