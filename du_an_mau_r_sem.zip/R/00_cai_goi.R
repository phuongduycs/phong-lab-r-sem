# Chạy MỘT lần trên máy mới: cài các gói dự án cần
goi <- c("lavaan", "semTools", "seminr", "psych", "ggplot2", "flextable", "quarto", "knitr", "rmarkdown", "renv")
thieu <- setdiff(goi, rownames(installed.packages()))
if (length(thieu)) install.packages(thieu)
# Khoá phiên bản gói để người khác tái lập đúng (tạo renv.lock):
# renv::init()       # lần đầu
# renv::snapshot()   # mỗi khi cài/cập nhật gói
# Người nhận dự án chỉ cần: renv::restore()
