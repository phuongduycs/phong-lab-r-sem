# =============================================================================
# 01_phan_tich.R: chạy toàn bộ phân tích, lưu kết quả cho bản thảo và slide
# Dự án mẫu Phòng Lab R–SEM · Nguyễn Bình Phương Duy · CC BY-NC 4.0
# Chạy một lần (hoặc mỗi khi dữ liệu đổi):  source("R/01_phan_tich.R")
# Bản thảo (ban_thao/manuscript.qmd) chỉ ĐỌC ket_qua/ket_qua.rds, nên render rất nhanh.
# =============================================================================
library(lavaan)
library(semTools)
library(seminr)

df <- read.csv("data/khao_sat_sach.csv", fileEncoding = "UTF-8")
khai_niem <- list(HI = paste0("HI", 1:4), DD = paste0("DD", 1:4), NT = paste0("NT", 1:4),
                  TD = paste0("TD", 1:3), YD = paste0("YD", 1:3))
items <- unlist(khai_niem, use.names = FALSE)

# ---- 1. Mô hình đo lường (CFA) ----------------------------------------------
m_cfa <- paste(sprintf("%s =~ %s", names(khai_niem), sapply(khai_niem, paste, collapse = " + ")), collapse = "\n")
cfa_fit <- cfa(m_cfa, data = df, estimator = "MLR")

std <- subset(standardizedSolution(cfa_fit), op == "=~")
tai <- data.frame(khai_niem = std$lhs, bien = std$rhs, tai = std$est.std)

alpha_k <- sapply(khai_niem, function(v) psych::alpha(df[v], warnings = FALSE)$total$raw_alpha)
cr_k  <- compRelSEM(cfa_fit, simplify = TRUE)
ave_k <- AVE(cfa_fit)
do_luong <- data.frame(khai_niem = names(khai_niem), so_bien = lengths(khai_niem),
                       tai_min = tapply(tai$tai, tai$khai_niem, min)[names(khai_niem)],
                       tai_max = tapply(tai$tai, tai$khai_niem, max)[names(khai_niem)],
                       alpha = alpha_k, CR = cr_k[names(khai_niem)], AVE = ave_k[names(khai_niem)],
                       row.names = NULL)
htmt_m <- htmt(m_cfa, data = df)
fit_cfa <- fitMeasures(cfa_fit, c("chisq.scaled", "df.scaled", "pvalue.scaled", "cfi.robust",
                                  "tli.robust", "rmsea.robust", "rmsea.ci.lower.robust",
                                  "rmsea.ci.upper.robust", "srmr"))

# ---- 2. Mô hình cấu trúc (CB-SEM) -------------------------------------------
gia_thuyet <- data.frame(
  H  = paste0("H", 1:7),
  tu = c("DD", "DD", "HI", "NT", "HI", "NT", "TD"),
  den = c("HI", "TD", "TD", "TD", "YD", "YD", "YD"))
m_sem <- paste(m_cfa, "
  HI ~ DD
  TD ~ DD + HI + NT
  YD ~ HI + NT + TD", sep = "\n")
sem_fit <- sem(m_sem, data = df, estimator = "MLR")
ss <- subset(standardizedSolution(sem_fit), op == "~")
cau_truc <- merge(gia_thuyet, ss[, c("lhs", "rhs", "est.std", "se", "z", "pvalue", "ci.lower", "ci.upper")],
                  by.x = c("den", "tu"), by.y = c("lhs", "rhs"))
cau_truc <- cau_truc[order(cau_truc$H), c("H", "tu", "den", "est.std", "se", "z", "pvalue", "ci.lower", "ci.upper")]
cau_truc$ket_luan <- ifelse(cau_truc$pvalue < .05 & cau_truc$est.std > 0, "Supported", "Not supported")
r2_sem <- lavInspect(sem_fit, "r2")[c("HI", "TD", "YD")]
fit_sem <- fitMeasures(sem_fit, names(fit_cfa))

# ---- 3. PLS-SEM (seminr), dùng làm kiểm tra độ vững ---------------------------
mm <- do.call(constructs, lapply(names(khai_niem), function(k) composite(k, khai_niem[[k]])))
sm <- relationships(paths(from = "DD", to = c("HI", "TD")), paths(from = "HI", to = c("TD", "YD")),
                    paths(from = "NT", to = c("TD", "YD")), paths(from = "TD", to = "YD"))
pls <- estimate_pls(df, mm, sm)
boot <- bootstrap_model(pls, nboot = 5000, seed = 2026)
bp <- summary(boot)$bootstrapped_paths
pls_path <- data.frame(duong = rownames(bp), beta = bp[, "Original Est."], t = bp[, "T Stat."],
                       ci_l = bp[, "2.5% CI"], ci_u = bp[, "97.5% CI"], row.names = NULL)

# ---- 4. Lưu ------------------------------------------------------------------
dir.create("ket_qua", showWarnings = FALSE)
ket_qua <- list(n = nrow(df), mo_ta = list(nu = mean(df$gioi_tinh == "Nữ", na.rm = TRUE),
                                          nen_tang = sort(table(df$nen_tang), decreasing = TRUE)),
                do_luong = do_luong, tai = tai, htmt = htmt_m, fit_cfa = fit_cfa,
                cau_truc = cau_truc, r2 = r2_sem, fit_sem = fit_sem, pls_path = pls_path,
                phien_ban = list(R = R.version.string, lavaan = as.character(packageVersion("lavaan")),
                                 semTools = as.character(packageVersion("semTools")),
                                 seminr = as.character(packageVersion("seminr"))),
                ngay = Sys.Date())
saveRDS(ket_qua, "ket_qua/ket_qua.rds")
write.csv(do_luong, "ket_qua/bang_do_luong.csv", row.names = FALSE)
write.csv(cau_truc, "ket_qua/bang_gia_thuyet.csv", row.names = FALSE)
cat("Đã lưu ket_qua/ket_qua.rds lúc", format(Sys.time()), "\n")
